import { CategoryListPipe } from './category-list.pipe';

describe('CategoryListPipe', () => {
  it('create an instance', () => {
    const pipe = new CategoryListPipe();
    expect(pipe).toBeTruthy();
  });
});
